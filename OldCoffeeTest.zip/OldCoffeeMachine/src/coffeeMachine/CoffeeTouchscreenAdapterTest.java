package coffeeMachine;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CoffeeTouchscreenAdapterTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testCoffeeTouchscreenAdapter() {
		OldCoffeeMachine oldMachine = new OldCoffeeMachine();
		CoffeeTouchscreenAdapter testAdapter = new CoffeeTouchscreenAdapter(oldMachine);
		assertNotNull(testAdapter);
	}

	@Test
	public void testChooseFirstSelectiont() {
		OldCoffeeMachine oldMachine = new OldCoffeeMachine();
		CoffeeTouchscreenAdapter testAdapter = new CoffeeTouchscreenAdapter(oldMachine);
		testAdapter.chooseFirstSelection();
		assertEquals("A-selected",testAdapter.chooseFirstSelectiont());
	}

	@Test
	public void testChooseSecondSelectiont() {
		OldCoffeeMachine oldMachine = new OldCoffeeMachine();
		CoffeeTouchscreenAdapter testAdapter = new CoffeeTouchscreenAdapter(oldMachine);
		testAdapter.chooseFirstSelection();
		assertEquals("B-selected",testAdapter.chooseSecondSelectiont());
	}

}
