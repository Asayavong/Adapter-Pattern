package coffeeMachine;

public class OldCoffeeMachine {
	
	public String selectA() {
		return "A-selected";
	}
	
	public String selectB() {
		return "B-selected";
	}

}
