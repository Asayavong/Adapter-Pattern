package coffeeMachine;

public class CoffeeTouchscreenAdapter implements CoffeeMachineInterface {

	OldCoffeeMachine theMachine;

	public CoffeeTouchscreenAdapter(OldCoffeeMachine newMachine) {
		theMachine = newMachine;
	}
	
	public void chooseFirstSelection() {
		theMachine.selectA();
	}
	
	public void chooseSecondSelection() {
		theMachine.selectB();
}
	//these methods are used for testing
	public String chooseFirstSelectiont() {
		return theMachine.selectA();
	}
	public String chooseSecondSelectiont() {
		return theMachine.selectB();
}
}