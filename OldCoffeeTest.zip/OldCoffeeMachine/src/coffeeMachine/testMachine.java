package coffeeMachine;
public class testMachine {

	public static void main(String[] args) {
		OldCoffeeMachine testMachine = new OldCoffeeMachine();
		CoffeeTouchscreenAdapter testAdapter = new CoffeeTouchscreenAdapter(testMachine);
		testAdapter.chooseFirstSelection();
		testAdapter.chooseSecondSelection();

	}

}
